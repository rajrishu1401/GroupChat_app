import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class NewMessagesWidget extends StatefulWidget{
  const NewMessagesWidget({super.key});

  @override
  State<NewMessagesWidget> createState() {
    return _NewMessagesWidgetState();
  }
}

class _NewMessagesWidgetState extends State<NewMessagesWidget>{
  final _messageController=TextEditingController();
  @override
  void dispose() {
    _messageController.dispose();
    super.dispose();
  }
  void _submitMessage() async {
    final enteredMassage=_messageController.text;
    if(enteredMassage.trim().isEmpty){
      return;
    }
    FocusScope.of(context).unfocus();
    _messageController.clear();
    final user=FirebaseAuth.instance.currentUser!;
    final userData=await FirebaseFirestore.instance.collection('users').doc(user.uid).get();
    FirebaseFirestore.instance.collection('chat').add({
      'text':enteredMassage,
      'createdAt':Timestamp.now(),
      'userId':user.uid,
      'userName':userData.data()!['user_name'],
      'userImage':userData.data()!['image_url']
    });
  }
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 15,right: 1,bottom: 14,),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: _messageController,
              enableSuggestions: true,
              autocorrect: true,
              textCapitalization: TextCapitalization.sentences,
              decoration: const InputDecoration(
                label: Text('send a message...')
              ),
            ),
          ),
          IconButton(onPressed: _submitMessage,
              color: Theme.of(context).colorScheme.primary,
              icon: const Icon(Icons.send))
        ],
      ),
    );
  }

}