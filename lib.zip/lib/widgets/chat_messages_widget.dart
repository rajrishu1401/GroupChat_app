import 'package:chat/widgets/message_bubble_widget.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ChatMessagesWidget extends StatelessWidget {
  const ChatMessagesWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: FirebaseFirestore.instance
          .collection('chat')
          .orderBy(
            'createdAt',
            descending: true,
          )
          .snapshots(),
      builder: (context, chatSnapshots) {
        if (chatSnapshots.connectionState == ConnectionState.waiting) {
          return const Center(
            child: CircularProgressIndicator(),
          );
        }
        if (!chatSnapshots.hasData || chatSnapshots.data!.docs.isEmpty) {
          return const Center(child: Text('no message'));
        }
        if (chatSnapshots.hasError) {
          return const Center(child: Text('Something went wrong!'));
        }
        final loadedMessages = chatSnapshots.data!.docs;
        final currentUserId = FirebaseAuth.instance.currentUser!.uid;
        var isCurrentUser = false;
        return ListView.builder(
          padding: const EdgeInsets.only(
            bottom: 40,
            right: 13,
            left: 12,
          ),
          reverse: true,
          itemCount: loadedMessages.length,
          itemBuilder: (context, index) {
            if (loadedMessages[index].data()['userId'] == currentUserId) {
              isCurrentUser = true;
            }
            else{
              isCurrentUser=false;
            }
            if ((index+1)<loadedMessages.length) {
              if (loadedMessages[index].data()['userId'] ==
                  loadedMessages[index+1].data()['userId']) {
                return MessageBubble.next(
                    message: loadedMessages[index].data()['text'],
                    isMe: isCurrentUser);
              }
            }
            return MessageBubble.first(
                userImage: loadedMessages[index].data()['userImage'],
                username: loadedMessages[index].data()['userName'],
                message: loadedMessages[index].data()['text'],
                isMe: isCurrentUser);
          },
        );
      },
    );
  }
}
