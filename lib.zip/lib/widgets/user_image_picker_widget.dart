import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

class UserImagePickerWidget extends StatefulWidget{
  const UserImagePickerWidget({super.key,required this.transferImage});
  final void Function(File image) transferImage;
  @override
  State<UserImagePickerWidget> createState() {
    return _UserImagePickerWidgetState();
  }

}

class _UserImagePickerWidgetState extends State<UserImagePickerWidget>{
  File? selectedImage;
  void _saveImage() async {
    final image= await ImagePicker().pickImage(source: ImageSource.camera);
    if(image!=null){
      setState(() {
        selectedImage=File(image.path);
        widget.transferImage(selectedImage!);
      });
    }
  }
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        CircleAvatar(
          radius: 40,
          backgroundColor: Colors.grey,
          foregroundImage: selectedImage!=null? FileImage(selectedImage!):null,
        ),
        TextButton.icon(onPressed: _saveImage, icon:const Icon(Icons.image),label:Text('Add Image',style: TextStyle(color: Theme.of(context).colorScheme.primary),))
      ],
    );
  }
}